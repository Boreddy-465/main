void delay(void); 
                  
void delay(){
  int j ; 
  for(j=0;j<100;j++)
   {}       
 }


